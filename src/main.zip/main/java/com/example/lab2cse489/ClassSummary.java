package com.example.lab2cse489;

public class ClassSummary {


    String id ="";

    String course="";
    String type = "";
    String date = "";
    String lecture = "";
    String topic = "";
    String summary = "";

    public ClassSummary(String id,String course, String type, String date, String lecture, String topic, String summary) {
        this.id = id;
        this.course=course;
        this.type = type;
        this.date = date;
        this.lecture = lecture;
        this.topic = topic;
        this.summary = summary;
    }
}
